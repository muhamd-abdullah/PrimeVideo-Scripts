import requests

url = "https://s3-dub-ww.cf.dash.row.aiv-cdn.net/dm/2$HFfn88x79JpN7GTdPBIsZ-Gf5_8~/f9b9/09a6/4d28/40f2-979f-f7198e303dd1/f58d50df-b38c-456a-ac07-59f78a4d1a9a_audio_396.mp4?amznDtid=AOAGZA014O5RE"  # Replace with your desired URL
rsp=requests.get(url, stream=True)
print(rsp.raw._connection.sock.getpeername())